
class QueryClient:
    API = "http://localhost:5001/api/executeQuery/execute"
    @staticmethod
    def execute():
        pass