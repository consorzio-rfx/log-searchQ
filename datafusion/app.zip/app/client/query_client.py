
class QueryClient:
    @staticmethod
    def execute():
        pass